package com.aborayan.alhasibat;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

final class CalculatorEngine {
    static final class Result {
        final Double value;
        final boolean divideByZero;
        private Result(Double value, boolean divideByZero) {
            this.value = value;
            this.divideByZero = divideByZero;
        }
        static Result ok(double value) { return new Result(value, false); }
        static Result invalid() { return new Result(null, false); }
        static Result divZero() { return new Result(null, true); }
    }

    private enum Type { NUMBER, OP, LPAREN, RPAREN }
    private record Token(Type type, double number, char op) {
        static Token number(double n) { return new Token(Type.NUMBER, n, '\0'); }
        static Token op(char c) { return new Token(Type.OP, 0, c); }
        static Token left() { return new Token(Type.LPAREN, 0, '\0'); }
        static Token right() { return new Token(Type.RPAREN, 0, '\0'); }
    }

    static Result evaluate(String raw) {
        if (raw == null || raw.isBlank()) return Result.invalid();
        try {
            List<Token> tokens = tokenize(raw.replace('×', '*').replace('÷', '/').replace('−', '-'));
            if (tokens == null || tokens.isEmpty()) return Result.invalid();
            List<Token> rpn = toRpn(tokens);
            if (rpn == null) return Result.invalid();
            return evaluateRpn(rpn);
        } catch (RuntimeException ex) {
            return Result.invalid();
        }
    }

    private static List<Token> tokenize(String s) {
        List<Token> out = new ArrayList<>();
        int i = 0;
        boolean previousIsValue = false;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (Character.isWhitespace(c)) { i++; continue; }
            if (Character.isDigit(c) || c == '.') {
                int start = i;
                int dots = 0;
                while (i < s.length() && (Character.isDigit(s.charAt(i)) || s.charAt(i) == '.')) {
                    if (s.charAt(i) == '.') dots++;
                    i++;
                }
                if (dots > 1) return null;
                double value = Double.parseDouble(s.substring(start, i));
                if (i < s.length() && s.charAt(i) == '%') { value /= 100d; i++; }
                out.add(Token.number(value));
                previousIsValue = true;
                continue;
            }
            if (c == '(') {
                if (previousIsValue) out.add(Token.op('*'));
                out.add(Token.left());
                previousIsValue = false;
                i++;
                continue;
            }
            if (c == ')') {
                out.add(Token.right());
                previousIsValue = true;
                i++;
                continue;
            }
            if (c == '+' || c == '-' || c == '*' || c == '/') {
                if ((c == '+' || c == '-') && !previousIsValue) {
                    if (c == '-') {
                        out.add(Token.number(-1));
                        out.add(Token.op('*'));
                    }
                    i++;
                    continue;
                }
                out.add(Token.op(c));
                previousIsValue = false;
                i++;
                continue;
            }
            if (c == '%') { i++; continue; }
            return null;
        }
        return out;
    }

    private static int precedence(char op) { return (op == '*' || op == '/') ? 2 : 1; }

    private static List<Token> toRpn(List<Token> tokens) {
        List<Token> output = new ArrayList<>();
        Deque<Token> operators = new ArrayDeque<>();
        for (Token token : tokens) {
            switch (token.type) {
                case NUMBER -> output.add(token);
                case OP -> {
                    while (!operators.isEmpty() && operators.peek().type == Type.OP
                            && precedence(operators.peek().op) >= precedence(token.op)) {
                        output.add(operators.pop());
                    }
                    operators.push(token);
                }
                case LPAREN -> operators.push(token);
                case RPAREN -> {
                    boolean found = false;
                    while (!operators.isEmpty()) {
                        Token t = operators.pop();
                        if (t.type == Type.LPAREN) { found = true; break; }
                        output.add(t);
                    }
                    if (!found) return null;
                }
            }
        }
        while (!operators.isEmpty()) {
            Token t = operators.pop();
            if (t.type == Type.LPAREN || t.type == Type.RPAREN) return null;
            output.add(t);
        }
        return output;
    }

    private static Result evaluateRpn(List<Token> rpn) {
        Deque<Double> stack = new ArrayDeque<>();
        for (Token token : rpn) {
            if (token.type == Type.NUMBER) {
                stack.push(token.number);
                continue;
            }
            if (stack.size() < 2) return Result.invalid();
            double b = stack.pop();
            double a = stack.pop();
            double r;
            switch (token.op) {
                case '+' -> r = a + b;
                case '-' -> r = a - b;
                case '*' -> r = a * b;
                case '/' -> {
                    if (b == 0d) return Result.divZero();
                    r = a / b;
                }
                default -> { return Result.invalid(); }
            }
            stack.push(r);
        }
        if (stack.size() != 1) return Result.invalid();
        double value = stack.pop();
        if (!Double.isFinite(value)) return Result.invalid();
        return Result.ok(value);
    }
}
