package com.aborayan.alhasibat;

final class ArabicNumberWords {
    private static final String[] ONES = {"", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة", "عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر"};
    private static final String[] TENS = {"", "", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون"};
    private static final String[] HUNDREDS = {"", "مئة", "مئتان", "ثلاثمئة", "أربعمئة", "خمسمئة", "ستمئة", "سبعمئة", "ثمانمئة", "تسعمئة"};

    static String convert(long number) {
        number = Math.abs(number);
        if (number == 0) return "صفر";
        StringBuilder result = new StringBuilder();
        long[] values = {1_000_000_000_000L, 1_000_000_000L, 1_000_000L, 1_000L};
        String[][] forms = {
                {"تريليون", "تريليونان", "تريليونات"},
                {"مليار", "ملياران", "مليارات"},
                {"مليون", "مليونان", "ملايين"},
                {"ألف", "ألفان", "آلاف"}
        };
        long remaining = number;
        for (int i = 0; i < values.length; i++) {
            long count = remaining / values[i];
            if (count > 0) {
                appendAnd(result);
                if (count == 1) result.append(forms[i][0]);
                else if (count == 2) result.append(forms[i][1]);
                else result.append(under1000((int) count)).append(' ').append(scaleWord(count, forms[i]));
                remaining %= values[i];
            }
        }
        if (remaining > 0) {
            appendAnd(result);
            result.append(under1000((int) remaining));
        }
        return result.toString();
    }

    private static void appendAnd(StringBuilder sb) {
        if (sb.length() > 0) sb.append(" و");
    }

    private static String scaleWord(long count, String[] forms) {
        if (count == 1) return forms[0];
        if (count == 2) return forms[1];
        if (count >= 3 && count <= 10) return forms[2];
        return forms[0];
    }

    private static String under1000(int n) {
        StringBuilder parts = new StringBuilder();
        int h = n / 100;
        int rest = n % 100;
        if (h > 0) parts.append(HUNDREDS[h]);
        if (rest > 0) {
            if (parts.length() > 0) parts.append(" و");
            if (rest < 20) parts.append(ONES[rest]);
            else {
                int tens = rest / 10;
                int ones = rest % 10;
                if (ones > 0) parts.append(ONES[ones]).append(" و");
                parts.append(TENS[tens]);
            }
        }
        return parts.toString();
    }
}
